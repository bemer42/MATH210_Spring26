"""
Created on Fri Feb  6 07:34:26 2026

@author: brooksemerick
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import optimize

# Objective: This script outputs some basic plotting commands 
# associated to Phase 1 - Worksheet 1 problem 2b.

# Discretize the domain with a vector, x
N = int(1e3)
x = np.linspace(-1, 10, N)  

# Create the function in part 1a
def f(x):
    return x ** 2 * np.exp(-x/2)

# Create a general numerical derivative using a centered difference
h = 1e-5
fp = lambda x: (f(x+h)-f(x-h)) / 2 / h

# Use built-in solver to calculate critical points
c_1 = optimize.root_scalar(fp, bracket=(0-.1, 0+.1), method="brentq")
c_2 = optimize.root_scalar(fp, bracket=(4-.1, 4+.1), method="brentq")

# Compile both roots into an array
c = np.array([c_1.root, c_2.root])

# Plot the graph of the function
plt.figure(1)
plt.plot(x, f(x), 'k-', linewidth=3, label='y = f(x)')
plt.plot(c, f(c), 'ro', linewidth=3, label='critical points')
plt.title('P1WS1 Polynomial with Critical Points', fontsize=20)
plt.xlabel('x', fontsize=15)
plt.ylabel('y=f(x)', fontsize=15)
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.grid(True, which='both')
plt.xlim([np.min(x), np.max(x)])
plt.ylim([np.min(f(x))-1, np.max(f(x))+1])
plt.legend()

# Show the plot:
plt.show()

# Save the file in high quality format as eps and png: 
plt.savefig('p1ws1_2b_plot.eps', format='eps')
plt.savefig('p1ws1_2b_plot.png', format='png')
